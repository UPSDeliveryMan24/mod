#pragma once
// Wave level generator.
//
// Pure C++17 with no Geode / Cocos dependency, so it can be compiled and
// tested on any machine (see tools/test_wavegen.cpp). It produces the *raw*
// (uncompressed) Geometry Dash level string; src/main.cpp compresses it with
// ZipUtils and hands it to the game.
//
// Geometry model
// --------------
// * 1 block = 30 units. Row r has its centre at y = 15 + 30 * r.
// * The wave moves at 45 degrees, so the generated "centre line" only ever
//   has a slope of +1, -1 or 0 (flat sections are meant to be zig-zagged).
// * Around the centre line there is an *ideal* free region of +/- halfGap.
//   Wall blocks are only placed OUTSIDE that region, rounded outwards to the
//   30-unit grid, so the centre line is guaranteed to stay clear of every
//   solid block. Only plain block objects (id 1) are used as solids.
// * Everything that is decoration is either unreachable (inside the walls)
//   or a trigger placed above the playable area.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <random>
#include <string>
#include <vector>

namespace wavegen {

constexpr float CELL = 30.f;
constexpr int   ROWS = 10;                 // playable height of ship/wave mode
constexpr float CEIL_Y = ROWS * CELL;      // 300

// Object ids. If an id is wrong for your GD version, fix it here only.
namespace oid {
constexpr int BLOCK        = 1;
constexpr int PORTAL_WAVE  = 660;
constexpr int SPEED_FAST   = 202;   // 2x
constexpr int SPEED_FASTER = 203;   // 3x
constexpr int SPEED_FASTEST = 1334; // 4x
constexpr int TRIG_COLOR   = 899;
constexpr int TRIG_PULSE   = 1006;
} // namespace oid

// Colour channel ids.
namespace ch {
constexpr int BG = 1000, GROUND = 1001, LINE = 1002;
constexpr int WALL_DEEP = 1, WALL_EDGE = 2, WALL_MID = 3, DECOR = 4;
} // namespace ch

struct Options {
    uint32_t seed = 1;
    int seconds = 45;        // length of the wave section in seconds
    int difficulty = 2;      // 0 Easy .. 4 Extreme
    int speed = 0;           // 0 = 1x, 1 = 2x, 2 = 3x, 3 = 4x
    int bpm = 120;           // used for pulse + colour-change timing
    int decoration = 2;      // 0 none, 1 colours + shaded walls, 2 = full
    std::string theme = "Random";
};

struct Result {
    std::string data;                 // raw level string (header + objects)
    int objects = 0;
    int columns = 0;                  // total columns (lead-in, corridor, tail)
    int corridorStart = 0;            // first column with walls
    int corridorEnd = 0;              // one past last column of the body
    float unitsPerSec = 0.f;
    std::vector<float> center;        // centre line y per column (units)
    std::string themeName;
};

// ---------------------------------------------------------------------------
// internals
// ---------------------------------------------------------------------------
namespace detail {

struct RGB { int r, g, b; };

struct Palette { RGB bg, ground, deep, mid, edge, decor; };

inline RGB hsv(float h, float s, float v) {
    h = std::fmod(h, 360.f);
    if (h < 0) h += 360.f;
    float c = v * s;
    float x = c * (1.f - std::fabs(std::fmod(h / 60.f, 2.f) - 1.f));
    float m = v - c;
    float r = 0, g = 0, b = 0;
    int sector = static_cast<int>(h / 60.f);
    switch (sector) {
        case 0: r = c; g = x; break;
        case 1: r = x; g = c; break;
        case 2: g = c; b = x; break;
        case 3: g = x; b = c; break;
        case 4: r = x; b = c; break;
        default: r = c; b = x; break;
    }
    auto to8 = [&](float f) { return std::clamp(static_cast<int>(std::lround((f + m) * 255.f)), 0, 255); };
    return { to8(r), to8(g), to8(b) };
}

inline Palette makePalette(float h) {
    Palette p;
    p.bg     = hsv(h,       0.80f, 0.20f);
    p.ground = hsv(h,       0.75f, 0.32f);
    p.deep   = hsv(h,       0.85f, 0.30f);
    p.mid    = hsv(h + 12,  0.75f, 0.60f);
    p.edge   = hsv(h + 24,  0.50f, 1.00f);
    p.decor  = hsv(h + 45,  0.65f, 0.90f);
    return p;
}

struct Theme { const char* name; std::vector<float> hues; };

inline const std::vector<Theme>& themes() {
    static const std::vector<Theme> t = {
        {"Neon",   {285, 320, 200, 170}},
        {"Sunset", {12, 28, 345, 300}},
        {"Ocean",  {200, 185, 220, 170}},
        {"Toxic",  {110, 90, 140, 70}},
        {"Candy",  {330, 290, 200, 160}},
        {"Ember",  {15, 32, 0, 350}},
        {"Frost",  {195, 212, 185, 228}},
    };
    return t;
}

struct Rng {
    std::mt19937 g;
    explicit Rng(uint32_t s) : g(s) {}
    uint32_t next() { return g(); }
    // Own helpers (instead of <random> distributions) so the same seed gives
    // the same level on every platform.
    int range(int a, int b) { return a + static_cast<int>(next() % static_cast<uint32_t>(b - a + 1)); }
    float unit() { return static_cast<float>(next() >> 8) / 16777216.f; }
};

inline std::string num(float v) {
    char buf[32];
    if (std::fabs(v - std::round(v)) < 0.0005f) {
        std::snprintf(buf, sizeof buf, "%d", static_cast<int>(std::lround(v)));
    } else {
        std::snprintf(buf, sizeof buf, "%.3f", v);
        std::string s = buf;
        while (!s.empty() && s.back() == '0') s.pop_back();
        if (!s.empty() && s.back() == '.') s.pop_back();
        return s;
    }
    return buf;
}

// Collects objects as "k,v,k,v;" records.
struct Writer {
    std::string body;
    int count = 0;

    Writer& begin(int id, float x, float y) {
        body += "1," + std::to_string(id) + ",2," + num(x) + ",3," + num(y);
        ++count;
        return *this;
    }
    Writer& kv(int key, float v) { body += "," + std::to_string(key) + "," + num(v); return *this; }
    Writer& kv(int key, int v)   { body += "," + std::to_string(key) + "," + std::to_string(v); return *this; }
    void end() { body += ";"; }
};

inline std::string channelEntry(int id, RGB c) {
    return "1_" + std::to_string(c.r) + "_2_" + std::to_string(c.g) + "_3_" + std::to_string(c.b) +
           "_11_255_12_255_13_255_4_-1_6_" + std::to_string(id) + "_7_1_15_1_18_0_8_1|";
}

struct DiffParams { float gapRows; int minRun; int maxRun; float flatChance; };

inline DiffParams diffParams(int d) {
    static const DiffParams P[5] = {
        {7.0f, 6, 16, 0.25f},   // Easy
        {5.5f, 5, 12, 0.20f},   // Normal
        {4.2f, 3,  9, 0.12f},   // Hard
        {3.2f, 2,  6, 0.08f},   // Insane
        {2.4f, 2,  4, 0.00f},   // Extreme
    };
    return P[std::clamp(d, 0, 4)];
}

inline float speedUnitsPerSec(int s) {
    static const float U[4] = {311.58f, 387.42f, 468.0f, 576.0f};
    return U[std::clamp(s, 0, 3)];
}

inline float smooth(float t) { t = std::clamp(t, 0.f, 1.f); return t * t * (3.f - 2.f * t); }

} // namespace detail

// ---------------------------------------------------------------------------
// public entry point
// ---------------------------------------------------------------------------
inline Result generate(Options opt) {
    using namespace detail;
    Rng rng(opt.seed);

    const DiffParams dp = diffParams(opt.difficulty);
    const float U = speedUnitsPerSec(opt.speed);
    const float hgTarget = dp.gapRows * CELL * 0.5f;   // half gap of the corridor
    const float hgOpen = 135.f;                        // half gap of the open funnel ends

    // --- layout in columns -------------------------------------------------
    const int LEAD = 8;          // empty columns before the funnel starts
    const int FUNNEL = 10;
    const int C0 = LEAD + 2;     // first column with walls
    const int bodyCols = std::max(30, static_cast<int>(std::lround(opt.seconds * U / CELL)));
    const int TAIL = FUNNEL + 4;
    const int N = C0 + bodyCols + TAIL;

    // --- centre line -------------------------------------------------------
    std::vector<float> c(N, 150.f);
    {
        const float lo = hgTarget, hi = CEIL_Y - hgTarget;
        float y = std::clamp(150.f, lo, hi);
        int dir = (rng.next() & 1) ? 1 : -1;
        int left = 0;
        for (int i = C0; i < N; ++i) {
            if (i >= C0 + bodyCols) { c[i] = y; continue; }
            if (i >= C0 + FUNNEL) {            // body proper (funnel stays flat)
                if (left <= 0) {
                    if (dp.flatChance > 0.f && rng.unit() < dp.flatChance) {
                        dir = 0;
                        left = rng.range(2, 4);
                    } else {
                        dir = (dir == 0) ? ((rng.next() & 1) ? 1 : -1) : -dir;
                        left = rng.range(dp.minRun, dp.maxRun);
                    }
                }
                if (dir != 0 && (y + dir * CELL > hi || y + dir * CELL < lo)) dir = -dir;
                y += dir * CELL;
                --left;
            }
            c[i] = y;
        }
    }

    // --- header / palette --------------------------------------------------
    const auto& th = themes();
    int themeIdx = rng.range(0, static_cast<int>(th.size()) - 1);
    for (size_t t = 0; t < th.size(); ++t)
        if (opt.theme == th[t].name) themeIdx = static_cast<int>(t);
    const Theme& theme = th[themeIdx];

    const bool deco = opt.decoration >= 1;
    const bool full = opt.decoration >= 2;

    Writer w;

    // --- objects: lead-in portals -------------------------------------------
    if (opt.speed > 0) {
        int sid = opt.speed == 1 ? oid::SPEED_FAST : opt.speed == 2 ? oid::SPEED_FASTER : oid::SPEED_FASTEST;
        w.begin(sid, 3 * CELL + 15, 75); w.end();
    }
    w.begin(oid::PORTAL_WAVE, 6 * CELL + 15, 75); w.end();

    // --- objects: walls -----------------------------------------------------
    for (int i = C0; i < N; ++i) {
        float hg;
        if (i < C0 + FUNNEL)
            hg = hgOpen + (hgTarget - hgOpen) * smooth(static_cast<float>(i - C0) / FUNNEL);
        else if (i >= C0 + bodyCols)
            hg = hgTarget + (hgOpen - hgTarget) * smooth(static_cast<float>(i - (C0 + bodyCols)) / FUNNEL);
        else
            hg = hgTarget;

        // centre line extent over this column (conservative: 3 neighbours)
        float cmin = c[i], cmax = c[i];
        for (int k = std::max(0, i - 1); k <= std::min(N - 1, i + 1); ++k) {
            cmin = std::min(cmin, c[k]);
            cmax = std::max(cmax, c[k]);
        }
        const int bottomRows = std::clamp(static_cast<int>(std::floor((cmin - hg) / CELL)), 0, ROWS);
        const int topStart = std::clamp(static_cast<int>(std::ceil((cmax + hg) / CELL)), 0, ROWS);

        auto placeCell = [&](int row, int dist) {
            float x = i * CELL + CELL / 2, y = row * CELL + CELL / 2;
            w.begin(oid::BLOCK, x, y);
            if (deco) {
                int channel = dist == 0 ? ch::WALL_EDGE : dist == 1 ? ch::WALL_MID : ch::WALL_DEEP;
                w.kv(21, channel);
            }
            w.end();
            // studs: unreachable diamonds on the inner wall cells
            if (full && dist >= 1 && ((i + row) % 2 == 0) && rng.unit() < 0.65f) {
                w.begin(oid::BLOCK, x, y);
                w.kv(6, 45).kv(32, dist == 1 ? 0.5f : 0.62f).kv(21, ch::DECOR).kv(25, 2);
                w.end();
            }
        };

        for (int r = 0; r < bottomRows; ++r) placeCell(r, bottomRows - 1 - r);
        for (int r = topStart; r < ROWS; ++r) placeCell(r, r - topStart);
    }

    // --- objects: colour changes + pulses ------------------------------------
    const float beatSec = 60.f / static_cast<float>(std::max(30, opt.bpm));
    const float beatCols = (U / CELL) * beatSec;          // columns per beat
    const float startX = (C0 + 0.f) * CELL;
    const float endX = (C0 + bodyCols) * CELL;
    const int sectionBeats = 16;

    const int hueCount = static_cast<int>(theme.hues.size());
    auto paletteFor = [&](int section) { return makePalette(theme.hues[section % hueCount]); };

    if (deco) {
        const float sectionLen = sectionBeats * beatCols * CELL;
        int section = 1;
        for (float x = startX + sectionLen; x < endX; x += sectionLen, ++section) {
            Palette p = paletteFor(section);
            struct Target { int channel; RGB col; };
            const Target targets[] = {
                {ch::BG, p.bg}, {ch::GROUND, p.ground}, {ch::LINE, p.edge},
                {ch::WALL_DEEP, p.deep}, {ch::WALL_MID, p.mid}, {ch::WALL_EDGE, p.edge}, {ch::DECOR, p.decor},
            };
            int k = 0;
            for (const auto& t : targets) {
                w.begin(oid::TRIG_COLOR, x, CEIL_Y + 45 + 30 * (k++ % 4));
                w.kv(36, 1).kv(7, t.col.r).kv(8, t.col.g).kv(9, t.col.b)
                 .kv(10, beatSec * 2.f).kv(23, t.channel).kv(35, 1.f);
                w.end();
            }
        }
    }

    if (full) {
        const float step = 4.f * beatCols * CELL;          // one pulse every 4 beats
        int k = 0;
        for (float x = startX + 2 * CELL; x < endX; x += step, ++k) {
            for (int target : {ch::WALL_EDGE, ch::DECOR}) {
                w.begin(oid::TRIG_PULSE, x, CEIL_Y + 45 + 30 * (target % 4));
                w.kv(36, 1).kv(7, 255).kv(8, 255).kv(9, 255)
                 .kv(45, 0.f).kv(46, 0.05f).kv(47, beatSec * 0.8f)
                 .kv(48, 0).kv(51, target).kv(52, 0);
                w.end();
            }
        }
    }

    // --- header ----------------------------------------------------------------
    std::string header = "kS38,";
    if (deco) {
        Palette p0 = paletteFor(0);
        header += channelEntry(ch::BG, p0.bg);
        header += channelEntry(ch::GROUND, p0.ground);
        header += channelEntry(ch::LINE, p0.edge);
        header += channelEntry(ch::WALL_DEEP, p0.deep);
        header += channelEntry(ch::WALL_MID, p0.mid);
        header += channelEntry(ch::WALL_EDGE, p0.edge);
        header += channelEntry(ch::DECOR, p0.decor);
    } else {
        header += "1_40_2_125_3_255_11_255_12_255_13_255_4_-1_6_1000_7_1_15_1_18_0_8_1|"
                  "1_0_2_102_3_255_11_255_12_255_13_255_4_-1_6_1001_7_1_15_1_18_0_8_1|";
    }
    int bgTex = rng.range(1, 20), groundTex = rng.range(1, 17);
    header += ",kA13,0,kA15,0,kA16,0,kA14,,kA6," + std::to_string(bgTex) +
              ",kA7," + std::to_string(groundTex) +
              ",kA17,0,kA18,0,kS39,0,kA2,0,kA3,0,kA8,0,kA4,0,kA9,0,kA10,0,kA11,0;";

    Result res;
    res.data = header + w.body;
    res.objects = w.count;
    res.columns = N;
    res.corridorStart = C0;
    res.corridorEnd = C0 + bodyCols;
    res.unitsPerSec = U;
    res.center = std::move(c);
    res.themeName = theme.name;
    return res;
}

} // namespace wavegen
