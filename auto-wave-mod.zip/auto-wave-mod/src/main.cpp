#include <Geode/Geode.hpp>
#include <Geode/modify/LevelBrowserLayer.hpp>

#include <algorithm>
#include <random>
#include <string>

#include "WaveGen.hpp"

using namespace geode::prelude;

namespace {

int indexOf(std::string const& value, std::initializer_list<char const*> options, int fallback) {
    int i = 0;
    for (auto const* opt : options) {
        if (value == opt) return i;
        ++i;
    }
    return fallback;
}

wavegen::Options readOptions() {
    auto* mod = Mod::get();
    wavegen::Options o;

    int64_t seed = mod->getSettingValue<int64_t>("seed");
    if (seed <= 0) {
        std::random_device rd;
        seed = static_cast<int64_t>(rd() & 0x7fffffffu);
        if (seed == 0) seed = 1;
    }
    o.seed = static_cast<uint32_t>(seed);
    o.seconds = static_cast<int>(mod->getSettingValue<int64_t>("length"));
    o.bpm = static_cast<int>(mod->getSettingValue<int64_t>("bpm"));
    o.difficulty = indexOf(mod->getSettingValue<std::string>("difficulty"),
                           {"Easy", "Normal", "Hard", "Insane", "Extreme"}, 2);
    o.speed = indexOf(mod->getSettingValue<std::string>("speed"), {"1x", "2x", "3x", "4x"}, 0);
    o.decoration = indexOf(mod->getSettingValue<std::string>("decoration"), {"None", "Colors", "Full"}, 2);
    o.theme = mod->getSettingValue<std::string>("theme");
    return o;
}

void generateAndOpen() {
    auto const opts = readOptions();
    auto const result = wavegen::generate(opts);

    // Same call the vanilla "new level" button uses: creates an empty local
    // level and registers it in the player's My Levels list.
    GJGameLevel* level = GameLevelManager::sharedState()->createNewLevel();
    if (!level) {
        Notification::create("Could not create a level", NotificationIcon::Error)->show();
        return;
    }

    std::string name = Mod::get()->getSettingValue<std::string>("level-name") + " " + std::to_string(opts.seed);
    if (name.size() > 20) name.resize(20);   // GD's level name limit

    level->m_levelName = name;
    level->m_levelString = ZipUtils::compressString(result.data, false, 0);

    log::info("Generated '{}': {} objects, {} columns, theme {}, seed {}",
              name, result.objects, result.columns, result.themeName, opts.seed);

    Notification::create(
        fmt::format("Wave level ready: {} theme, {} objects", result.themeName, result.objects),
        NotificationIcon::Success
    )->show();

    CCDirector::get()->pushScene(CCTransitionFade::create(0.5f, EditLevelLayer::scene(level)));
}

} // namespace

class $modify(AutoWaveBrowser, LevelBrowserLayer) {
    bool init(GJSearchObject* search) {
        if (!LevelBrowserLayer::init(search)) return false;

        // Only on the real "My Levels" list, not on the list-builder overlay.
        if (m_isOverlay || !search || search->m_searchType != SearchType::MyLevels) return true;

        // Sit just left of the vanilla "new level" (+) button when it can be found.
        auto winSize = CCDirector::get()->getWinSize();
        CCPoint pos = { winSize.width - 100.f, 40.f };
        if (auto* newMenu = this->getChildByID("new-level-menu")) {
            if (auto* newBtn = newMenu->getChildByID("new-level-button")) {
                pos = this->convertToNodeSpace(newMenu->convertToWorldSpace(newBtn->getPosition()));
                pos.x -= newBtn->getScaledContentSize().width * 0.5f + 55.f;
            }
        }

        auto* spr = ButtonSprite::create("Wave Gen", "goldFont.fnt", "GJ_button_01.png", 0.7f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(AutoWaveBrowser::onAutoWave));
        btn->setID("auto-wave-button"_spr);
        btn->setPosition(pos);

        auto* menu = CCMenu::create();
        menu->setID("auto-wave-menu"_spr);
        menu->setPosition({ 0.f, 0.f });
        menu->addChild(btn);
        this->addChild(menu);

        return true;
    }

    void onAutoWave(CCObject*) {
        createQuickPopup(
            "Auto Wave",
            "Generate a new <cy>wave level</c> with your current mod settings, "
            "decorate it and open it in the editor?",
            "Cancel", "Generate",
            [](FLAlertLayer*, bool confirmed) {
                if (confirmed) generateAndOpen();
            }
        );
    }
};
