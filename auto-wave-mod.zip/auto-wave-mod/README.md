# Auto Wave Level (Geode mod)

Adds a **Wave Gen** button next to the "+" button in *My Levels*. It generates a random wave level, decorates it, saves it as a new local level and opens it in the editor.

Targets Geometry Dash 2.2081, Geode v5.x.

## Getting the `.geode` file

A `.geode` is a package that contains compiled binaries, so it has to be built with the Geode toolchain. Two ways:

**1. GitHub Actions (no local setup, builds every platform)**

1. Open `mod.json` and change `id` (e.g. `yourname.auto-wave`) and `developer`.
2. Create a GitHub repo, push this folder to it.
3. Open the repo's **Actions** tab, wait for *Build Geode Mod* to finish, download the **Build Output** artifact. It contains the `.geode`.
4. Drop it in your Geometry Dash `geode/mods` folder (or open it with Geode's mod manager).

**2. Locally** with the [Geode CLI](https://docs.geode-sdk.org/getting-started/geode-cli): `geode build`.

## Using it

*My Levels* -> **Wave Gen** -> Generate. Everything is configurable in the mod's settings: seed, length, difficulty, speed, decoration level, colour theme, BPM.

## How it works

`src/WaveGen.hpp` is a self-contained generator (no Geode dependency) that writes a Geometry Dash level string. `src/main.cpp` hooks `LevelBrowserLayer`, compresses that string with `ZipUtils::compressString` and loads it into a level created by `GameLevelManager::createNewLevel()`.

* A centre line is walked with only +1 / -1 / 0 slopes (what a 45 degree wave can follow). Walls are blocks placed strictly outside a clear band around that line, rounded outward to the block grid, so the path is always open.
* Decoration: 7 colour channels set up in the level header, walls shaded by distance from the corridor, a colour-change trigger set every 16 beats, pulse triggers every 4 beats, and rotated stud overlays inside the walls (unreachable, so they can't affect gameplay).

## Tests

The generator can be tested without the game:

```
g++ -std=c++17 -O2 -Wall -Wextra -I src tools/test_wavegen.cpp -o test_wavegen && ./test_wavegen
```

It parses every generated level back, checks the corridor is free of objects, and flies a simulated wave (10x10 hitbox, direction changes only every 50 ms) through 1,260 level variants.

## Things worth knowing

* Corridor edges are stepped blocks, not slopes. Slopes look nicer but need slope object ids that are easy to get wrong; if you want them, the ids live in the `oid` namespace at the top of `WaveGen.hpp`.
* Object ids and trigger property keys (colour trigger 899, pulse trigger 1006, key 21 colour channel, key 51/52 pulse target) are written from the GD level-format as documented by the community. If a colour change or pulse doesn't fire in-game, those are the place to look.
* Floor and ceiling are assumed to be 10 blocks apart (0-300 units), as in vanilla wave/ship mode.
