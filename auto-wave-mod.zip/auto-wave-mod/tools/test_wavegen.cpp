// Native test for src/WaveGen.hpp (no Geode needed).
//
//   g++ -std=c++17 -O2 -Wall -Wextra -I src tools/test_wavegen.cpp -o /tmp/test_wavegen && /tmp/test_wavegen
//
// For every seed / difficulty / speed / decoration combination it
//   1. re-parses the generated level string and checks it is well formed,
//   2. checks nothing solid or decorative sits inside the playable corridor
//      and that all triggers sit above the playable area,
//   3. flies a simulated wave through the level. The bot only gets to change
//      direction every 50 ms (3 frames), so it zig-zags the way a human does,
//      and it uses a real 10x10 hitbox against 30x30 blocks.
#include "WaveGen.hpp"

#include <cstdio>
#include <cstdlib>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

struct Obj { std::map<int, double> k; };

static bool parse(const std::string& data, std::vector<Obj>& out, std::string& header) {
    size_t semi = data.find(';');
    if (semi == std::string::npos) return false;
    header = data.substr(0, semi);
    size_t pos = semi + 1;
    while (pos < data.size()) {
        size_t e = data.find(';', pos);
        if (e == std::string::npos) return false;      // every record must end in ';'
        std::string rec = data.substr(pos, e - pos);
        pos = e + 1;
        std::vector<std::string> parts;
        std::stringstream ss(rec);
        std::string tok;
        while (std::getline(ss, tok, ',')) parts.push_back(tok);
        if (parts.size() % 2 != 0) return false;
        Obj o;
        for (size_t i = 0; i < parts.size(); i += 2) o.k[std::atoi(parts[i].c_str())] = std::atof(parts[i + 1].c_str());
        if (!o.k.count(1) || !o.k.count(2) || !o.k.count(3)) return false;
        out.push_back(std::move(o));
    }
    return true;
}

static int failures = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++failures; if (failures <= 15) { std::printf("FAIL: "); std::printf(__VA_ARGS__); std::printf("\n"); } } } while (0)

static bool simulate(const wavegen::Result& r, const std::set<std::pair<int,int>>& solid, int seedForMsg, int reactionFrames) {
    const float U = r.unitsPerSec;
    const float dt = 1.f / 240.f;
    const float half = 5.f;                         // wave hitbox 10x10
    float x = 6 * 30 + 15, y = 15.f;                // enters at the wave portal, on the ground
    int dir = 1;
    float sinceDecision = 1e9f;
    const float endX = r.columns * 30.f;
    auto centerAt = [&](float px) {
        float f = (px - 15.f) / 30.f;
        int i = std::clamp(static_cast<int>(std::floor(f)), 0, r.columns - 2);
        float t = std::clamp(f - i, 0.f, 1.f);
        return r.center[i] * (1 - t) + r.center[i + 1] * t;
    };
    while (x < endX) {
        sinceDecision += dt;
        if (sinceDecision >= reactionFrames / 60.f) {
            sinceDecision = 0;
            // aim a little ahead of the wave so it can anticipate the turns
            float target = centerAt(x + 20.f);
            dir = (target > y) ? 1 : -1;
        }
        x += U * dt;
        y += dir * U * dt;
        y = std::clamp(y, half, wavegen::CEIL_Y - half);      // slides along floor / ceiling
        int c0 = static_cast<int>(std::floor((x - half) / 30.f)), c1 = static_cast<int>(std::floor((x + half) / 30.f));
        int r0 = static_cast<int>(std::floor((y - half) / 30.f)), r1 = static_cast<int>(std::floor((y + half) / 30.f));
        for (int cc = c0; cc <= c1; ++cc)
            for (int rr = r0; rr <= r1; ++rr)
                if (solid.count({cc, rr})) {
                    std::printf("  crash seed=%d at x=%.0f y=%.0f (col %d row %d)\n", seedForMsg, x, y, cc, rr);
                    return false;
                }
    }
    return true;
}

int main() {
    using namespace wavegen;
    int runs = 0, crashes = 0;
    size_t maxObjects = 0, maxBytes = 0;

    for (int diff = 0; diff < 5; ++diff)
    for (int speed = 0; speed < 4; ++speed)
    for (int deco = 0; deco < 3; ++deco)
    for (uint32_t seed = 1; seed <= (speed == 0 && deco == 2 ? 120u : 12u); ++seed) {
        Options o;
        o.seed = seed * 7919u + diff;
        o.seconds = (seed % 3 == 0) ? 20 : 45;
        o.difficulty = diff; o.speed = speed; o.decoration = deco; o.bpm = 100 + (seed % 5) * 20;
        Result r = generate(o);
        ++runs;
        maxObjects = std::max<size_t>(maxObjects, r.objects);
        maxBytes = std::max(maxBytes, r.data.size());

        std::vector<Obj> objs; std::string header;
        bool ok = parse(r.data, objs, header);
        CHECK(ok, "parse failed seed=%u diff=%d", o.seed, diff);
        if (!ok) continue;
        CHECK(header.rfind("kS38,", 0) == 0, "header start");
        CHECK(static_cast<int>(objs.size()) == r.objects, "object count %zu vs %d", objs.size(), r.objects);

        std::set<std::pair<int,int>> solid;
        std::set<std::pair<int,int>> baseBlocks;
        bool sawWavePortal = false;
        for (auto& ob : objs) {
            int id = static_cast<int>(ob.k[1]);
            double ox = ob.k[2], oy = ob.k[3];
            if (id == oid::BLOCK) {
                int col = static_cast<int>(std::floor(ox / 30)), row = static_cast<int>(std::floor(oy / 30));
                solid.insert({col, row});
                bool overlay = ob.k.count(32) > 0;
                if (!overlay) {
                    CHECK(baseBlocks.insert({col, row}).second, "duplicate block at %d,%d", col, row);
                }
                CHECK(row >= 0 && row < ROWS, "block row %d out of range", row);
                CHECK(col >= r.corridorStart, "block before corridor start (col %d)", col);
            } else if (id == oid::PORTAL_WAVE) {
                sawWavePortal = true;
            } else if (id == oid::TRIG_COLOR || id == oid::TRIG_PULSE) {
                CHECK(oy >= CEIL_Y + 30, "trigger inside playable area y=%.0f", oy);
                CHECK(ob.k.count(36) && ob.k[36] == 1, "trigger missing flag 36");
            }
        }
        CHECK(sawWavePortal, "no wave portal");

        // corridor must be genuinely open around the centre line
        for (int col = r.corridorStart; col < r.columns; ++col) {
            int cr = static_cast<int>(std::floor(r.center[col] / 30.f));
            CHECK(!solid.count({col, cr}), "centre line blocked at col %d", col);
        }

        if (!simulate(r, solid, static_cast<int>(o.seed), 3)) { ++crashes; ++failures; }
    }

    // determinism: same options -> identical output
    Options a; a.seed = 4242; a.difficulty = 3;
    CHECK(generate(a).data == generate(a).data, "generation is not deterministic");

    // different seeds -> different levels
    Options b = a; b.seed = 4243;
    CHECK(generate(a).data != generate(b).data, "different seeds gave identical levels");

    Options s; s.seed = 99; s.difficulty = 2;
    Result sample = generate(s);
    std::printf("runs=%d crashes=%d failures=%d\n", runs, crashes, failures);
    std::printf("sample (seed 99, normal+, 45s, 1x): %d columns, %d objects, %zu bytes, theme %s\n",
                sample.columns, sample.objects, sample.data.size(), sample.themeName.c_str());
    std::printf("largest generated level: %zu objects, %zu bytes\n", maxObjects, maxBytes);
    std::printf("header: %.300s...\n", sample.data.c_str());
    return failures ? 1 : 0;
}
