# Auto Wave Level

Adds a **Wave Gen** button to the *My Levels* list. One click builds a complete, decorated wave level in your editor.

- Random seeded corridor that always keeps a clear 45° path for the wave
- 5 difficulties, 1x-4x speed, adjustable length and BPM
- Decoration: colour palette themes, 3-tone shaded walls, colour changes every 16 beats, beat pulses and wall studs
- Same seed + same settings = same level

Change everything in the mod's settings.
